/* eslint-disable */
// // Enable runtimeCompiler: true in vue.config.js
// import Vue from 'vue';

// Vue.config.productionTip = false;

// // Local Variable reprensenting Component
// const GreetingComponent = {
//   name: "GreetingComponent",
//   template: `<h1>Hello from Greeting Component</h1>`
// };

// // Global Component
// Vue.component("greeting", {
//   template: `<h1>Hello from Greeting</h1>`
// });

// // Vue.component("GreetingComponent", {
// //   template: `<h1>Hello from Global Greeting Component</h1>`
// // });

// // Camel Case
// // Vue.component("greetingComponent", {
// //   template: `<h1>Hello from Global Greeting Component</h1>`
// // });

// // Kebab Case
// // Vue.component("greeting-component", {
// //   template: `<h1>Hello from Global Greeting Component</h1>`
// // });

// Vue.component("greeting-data", {
//   template: `<h1>Hello {{name}}</h1>`,
//   data: function () {
//     return {
//       name: "Synechron"
//     };
//   }
// });

// // Root Component
// new Vue({
//   el: '#app',
//   template: `
//     <div id="app">
//       <h1>Hello from Main Vue</h1>
//       <!-- <GreetingComponent />
//       <greetingComponent />
//       <greeting-component /> -->
//       <!-- <gComp />
//       <g-comp /> -->
//       <!-- <greeting /> -->
//       <!-- <GreetingComponent />
//       <greetingComponent /> -->
//       <!-- <greeting-component /> -->
//       <greeting-data />
//     </div>
//   `,
//   // components: { GreetingComponent }     // Local Component Registration
//   // components: { 
//   //   'gComp': GreetingComponent                      // Local Component Registration 
//   // }     
// });

// ----------------------------------------------------------- Pre-compiled Components

// import Vue from 'vue';
// import HelloComponent from './components/1_hello/HelloComponent';

// Vue.config.productionTip = false;

// // var vm = new Vue({
// //   render: function (createElement) {
// //     return createElement(HelloComponent);
// //   }
// // });

// // vm.$mount("#app");

// new Vue({
//   render: function (createElement) {
//     return createElement(HelloComponent);
//   }
// }).$mount("#app");

// // ------------------------------------------------------- Using Bootstrap 4
// // npm install bootstrap@4 jquery popper.js
// // import 'bootstrap';
// // import 'bootstrap/dist/css/bootstrap.min.css';

// // If you want to use SCSS files
// // npm i -D node-sass@4 sass-loader@10
// import 'bootstrap';
// import 'bootstrap/scss/bootstrap.scss';

// import Vue from 'vue';
// import HelloComponent from './components/1_hello/HelloComponent';

// Vue.config.productionTip = false;

// new Vue({
//   render: function (createElement) {
//     return createElement(HelloComponent);
//   }
// }).$mount("#app");

// // ------------------------------------------------------- Multi Component
// import 'bootstrap';
// import 'bootstrap/scss/bootstrap.scss';

// import Vue from 'vue';
// import ComponentOne from './components/2_multi-components/ComponentOne';
// import ComponentTwo from './components/2_multi-components/ComponentTwo';

// Vue.config.productionTip = false;

// new Vue({
//   render: function (createElement) {
//     return createElement(ComponentOne);
//   }
// }).$mount("#c1");

// new Vue({
//   render: function (createElement) {
//     return createElement(ComponentTwo);
//   }
// }).$mount("#c2");

// ------------------------------------------------------- Using Single Root
import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';

import Vue from 'vue';

import Root from './Root.vue';

Vue.config.productionTip = false;

new Vue({
  render: function (createElement) {
    return createElement(Root);
  }
}).$mount("#app");