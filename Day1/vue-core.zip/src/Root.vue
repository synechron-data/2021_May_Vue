<template>
	<div class="container">
		<!-- <component-one />
		<component-two /> -->

		<component-with-data />
	</div>
</template>

<script>
	// import ComponentOne from "./components/2_multi-components/ComponentOne";
	// import ComponentTwo from "./components/2_multi-components/ComponentTwo";

	// import ComponentOne from "./components/3_component-with-inline-style/ComponentOne";
	// import ComponentTwo from "./components/3_component-with-inline-style/ComponentTwo";

	// import ComponentOne from "./components/4_component-with-css/ComponentOne";
	// import ComponentTwo from "./components/4_component-with-css/ComponentTwo";

	// import ComponentOne from "./components/5_css-modules/ComponentOne";
	// import ComponentTwo from "./components/5_css-modules/ComponentTwo";

	// import ComponentOne from "./components/6_external-css/comp-one/ComponentOne";
	// import ComponentTwo from "./components/6_external-css/comp-two/ComponentTwo";

	// import ComponentOne from "./components/7_external-css-css-modules/comp-one/ComponentOne";
	// import ComponentTwo from "./components/7_external-css-css-modules/comp-two/ComponentTwo";
	import ComponentWithData from "./components/8_comp-data/ComponentWithData.vue";

	export default {
		name: "MainComponent",
		components: {
			// ComponentOne,
			// ComponentTwo,
			ComponentWithData,
		},
	};
</script>