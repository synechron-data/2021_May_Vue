<template>
	<div class="container">
		<h1 class="text-info">Hello from Component One</h1>
	</div>
</template>

<script>
	export default {
		name: "ComponentOne",
	};
</script>