<template>
	<div>
		<h1 class="text-success">Hello from Component Two</h1>
		<h2 class="card2">From Component Two</h2>
	</div>
</template>

<script>
	export default {
		name: "ComponentTwo",
	};
</script>

<style>
	@import './ComponentTwo.css';
</style>