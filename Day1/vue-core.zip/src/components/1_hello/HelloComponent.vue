<template>
	<div class="container">
		<h1 class="text-info">Hello World</h1>
		<h1 class="text-success">Hello World</h1>
	</div>
</template>

<script>
	export default {
		name: "HelloComponent",
	};
</script>