import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';

import Vue from 'vue';

import App from './App.vue';
import router from './router'

Vue.config.productionTip = false;

new Vue({
  router,

  render: function (createElement) {
    return createElement(App);
  }
}).$mount("#app");