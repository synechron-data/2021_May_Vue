<template>
	<home-component />
</template>

<script>
	import HomeComponent from "../components/home/HomeComponent.vue";
	export default {
		name: "Home",
		components: { HomeComponent },
	};
</script>
