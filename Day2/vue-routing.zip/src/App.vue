<template>
	<div class="container">
		<navigation-component />
		<div class="mt-5">
			<router-view />
		</div>
	</div>
</template>

<script>
	import NavigationComponent from "./components/bs-nav/NavigationComponent.vue";
	export default {
		name: "AppComponent",
		components: { NavigationComponent },
	};
</script>

<style>
	nav li a:hover {
		font-weight: bold;
		background-color: indianred;
		cursor: pointer;
	}

	nav li a.router-link-active,
	nav li a.router-link-exact-active {
		font-weight: bold;
		background-color: yellowgreen;
		cursor: pointer;
		border-radius: 15px;
		text-transform: uppercase;
	}
</style>
