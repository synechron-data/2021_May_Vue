import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';

import Vue from 'vue';

import Root from './Root.vue';
import changeContent from './directives/cc.directive';
import demoDirective from './directives/demo.directive';
import highlightDirective from './directives/highlight.directive';

Vue.config.productionTip = false;

Vue.directive('cc', changeContent);
Vue.directive('demo', demoDirective);
Vue.directive('highlight', highlightDirective);

Vue.filter('JSON', function (value) {
  return JSON.stringify(value);
});

new Vue({
  render: function (createElement) {
    return createElement(Root);
  }
}).$mount("#app");