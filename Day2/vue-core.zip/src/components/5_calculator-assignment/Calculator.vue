<template>
	<div class="row">
		<div class="col-sm-6 offset-sm-3">
			<form class="justify-content-center" @submit.prevent="add">
				<fieldset>
					<legend class="text-center">Calculator Assignment</legend>
					<div class="form-group">
						<label htmlFor="t1">Number One</label>
						<input
							type="text"
							class="form-control"
							id="t1"
							v-model.number="data.t1"
						/>
					</div>
					<div class="form-group">
						<label htmlFor="t2">Number Two</label>
						<input
							type="text"
							class="form-control"
							id="t2"
							v-model.number="data.t2"
						/>
					</div>
					<div class="form-group">
						<h3>Result: {{ result }}</h3>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-success btn-block">Add</button>
						<button type="reset" class="btn btn-primary btn-block" @click.prevent="reset">
							Reset
						</button>
					</div>
				</fieldset>
			</form>
		</div>
	</div>
</template>

<script>
	export default {
		name: "CalculatorAssignment",
		data() {
			return {
				data: {
					t1: 0,
					t2: 0,
				},
				result: 0,
			};
		},
		methods: {
			add() {
				this.result = this.data.t1 + this.data.t2;
			},
			reset() {
				this.result = 0;
				this.data.t1 = 0;
				this.data.t2 = 0;
			},
		},
	};
</script>