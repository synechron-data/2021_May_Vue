<template>
	<div>
		<h2 class="text-info">Custom Directives</h2>
		<!-- <h3 v-cc></h3>
		<h3 v-demo:data.test.a="'Hello from Demo File'"></h3> -->
		<h3 class="text-success">Employees List</h3>
		<ul class="list-group">
			<!-- <li v-for="e in employees" v-bind:key="e.id" class="list-group-item" v-highlight> -->
			<li
				v-for="e in employees"
				v-bind:key="e.id"
				class="list-group-item"
				v-highlight="'skyblue'"
			>
				{{ e.name }}
			</li>
		</ul>
	</div>
</template>

<script>
	export default {
		name: "CustomDirectiveDemo",
		data() {
			return {
				employees: [
					{ id: 1, name: "Manish" },
					{ id: 2, name: "Abhijeet" },
					{ id: 3, name: "Ramakant" },
					{ id: 4, name: "Subodh" },
					{ id: 5, name: "Abhishek" },
				],
			};
		},
	};
</script>