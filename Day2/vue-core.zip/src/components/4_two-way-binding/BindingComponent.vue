<template>
	<div>
		<!-- <input type="text" v-model="id" /> -->
		<!-- <input type="number" v-model="id" /> -->
		<!-- <input type="text" v-model.number="id" /> -->
		<input type="number" v-model.number="id" />
		<!-- <input type="number" v-model.number.lazy="id" /> -->
		<p>Id is: {{ id }}</p>

		<input type="text" v-model="name" />
		<p>Name is: {{ name }}</p>

		<textarea v-model="address"></textarea>
		<p>Address is: {{ address }}</p>

		<input type="checkbox" id="coding" value="Coding" v-model="hobbies" />
		<label for="coding">Coding</label>
		<input type="checkbox" id="running" value="Running" v-model="hobbies" />
		<label for="coding">Running</label>
		<input type="checkbox" id="cycling" value="Cycling" v-model="hobbies" />
		<label for="coding">Cycling</label>
		<p>Hobbies: {{ hobbies }}</p>

        <input type="radio" id="male" value="Male" v-model="gender">
        <label for="male">Male</label>
        <input type="radio" id="female" value="Female" v-model="gender">
        <label for="male">Female</label>
        <p>Gender: {{ gender }}</p>

        <select v-model="gender">
            <option disabled value="">Please select</option>
            <option>Male</option>
            <option>Female</option>
        </select>
        <p>Gender: {{ gender }}</p>
	</div>
</template>

<script>
	export default {
		name: "BindingComponent",
		data() {
			return {
				id: 0,
				name: "",
				address: "",
				hobbies: [],
				gender: "",
			};
		},
	};
</script>