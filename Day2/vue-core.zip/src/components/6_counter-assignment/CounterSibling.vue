<template>
	<div>
		<h1 class="text-info">This is a sibling Component to Counter</h1>
		<h2 class="text-success">Data via Prop: {{ current_count_via_prop }}</h2>
		<h2 class="text-success">
			Data via $root $emit: {{ current_count_via_root_emit }}
		</h2>
		<h2 class="text-success">
			Data via Event Bus: {{ current_count_via_ebus }}
		</h2>
	</div>
</template>

<script>
	import EventBus from "./EventBus";
	export default {
		name: "CounterSibling",
		data() {
			return {
				current_count_via_root_emit: 0,
				current_count_via_ebus: 0,
			};
		},
		props: {
			current_count_via_prop: {
				type: Number,
			},
		},
		mounted() {
			this.$root.$on("root-count-changed", (newCount) => {
				this.current_count_via_root_emit = newCount;
			});
			EventBus.$on("count-published", (newCount) => {
				this.current_count_via_ebus = newCount;
			});
		},
	};
</script>