<template>
	<div>
		<div class="text-center">
			<h3 class="text-info">Counter Component</h3>
		</div>
		<div class="row d-flex justify-content-center">
			<div class="col-sm-4">
				<input
					type="text"
					class="form-control"
					v-model.number="count"
					:disabled="flag"
				/>
			</div>
			<div class="col-sm-1">
				<button class="btn btn-info btn-block" :disabled="flag" @click="inc">
					+
				</button>
			</div>
			<div class="col-sm-1">
				<button class="btn btn-info btn-block" :disabled="flag" @click="dec">
					-
				</button>
			</div>
			<div class="col-sm-2">
				<button class="btn btn-info btn-block" :disabled="!flag" @click="reset">
					Reset
				</button>
			</div>
		</div>
	</div>
</template>

<script>
	import EventBus from "./EventBus";
	export default {
		name: "Counter",
		data() {
			this.clickCount = 0;
			return {
				count: 0,
				flag: false,
			};
		},
		props: {
			interval: {
				type: Number,
				default: 1,
			},
			onMax: {
				type: Function,
				default: function () {},
			},
		},
		methods: {
			manageClickCount() {
				this.clickCount += 1;
				if (this.clickCount > 9) {
					this.flag = true;
				}
			},
			inc() {
				this.manageClickCount();
				this.count += this.interval;
			},
			dec() {
				this.manageClickCount();
				this.count -= this.interval;
			},
			reset() {
				this.clickCount = 0;
				this.count = 0;
				this.flag = false;
			},
		},
		watch: {
			flag: function (newValue, oldValue) {
				if (newValue !== oldValue) {
					// this.onMax(this.flag);
					this.$emit("flag-changed", this.flag);
				}
			},
			count: function (newValue, oldValue) {
				if (newValue !== oldValue) {
					this.$emit("count-changed", this.count);
					// console.log(this.$root);
					this.$root.$emit("root-count-changed", this.count);
					EventBus.$emit("count-published", this.count);
				}
			},
		},
	};
</script>