<template>
	<div>
		<h1 class="text-info">Component With Props</h1>
		<h2>Id: {{ id }}</h2>
		<h2>Name: {{ name }}</h2>
		<h2>Address: {{ address }}</h2>
		<h2>Friends: {{ friends }}</h2>
		<hr />
		<h2>num: {{ num }}</h2>
		<h2>Computed num: {{ numDouble }}</h2>
		<h2>Computed city: {{ city }}</h2>
		<h2>Computed state: {{ state }}</h2>
	</div>
</template>

<script>
	export default {
		name: "ComponentWithProps",
		// props: ['id', 'name', 'address']
		data: function () {
			return {
				num: 20,
			};
		},
		props: {
			// id: {
			// 	type: Number,
			// 	required: true,
			// },
			id: {
				type: Number,
				default: 0,
			},
			name: {
				type: String,
				required: true,
			},
			address: {
				type: Object,
				required: true,
				// validator: (obj) => {
				// 	// console.log(obj);
				// 	Object.keys(obj).forEach((key) => {
				// 		console.log(key);
				// 	});
				// 	return true;
				// },
			},
			friends: {
				type: Array,
				required: true,
				validator: (prop) => prop.every((i) => typeof i === "string"),
			},
			greet: {
				type: Function,
				default: function () {
					alert("From the Component");
				},
			},
		},
		computed: {
			numDouble: function () {
				return this.num * 2;
			},
			city() {
				return `Your city is ${this.address.city}`;
			},
			state() {
				return `Your state is ${this.address.state}`;
			},
		},
	};
</script>