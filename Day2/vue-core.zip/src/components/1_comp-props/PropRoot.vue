<template>
	<div>
		<ComponentWithProps
			:name="'Manish'"
			:address="{ city: 'Pune', state: 'MH' }"
			:friends="['Abhijeet', 'Ramakant']"
		/>
	</div>
</template>

<script>
	import ComponentWithProps from "./ComponentWithProps.vue";
	export default {
		name: "PropRoot",
		components: { ComponentWithProps },
	};
</script>