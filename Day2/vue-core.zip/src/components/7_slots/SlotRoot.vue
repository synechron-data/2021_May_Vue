<template>
	<div>
		<List :items="listItems">
            <div slot-scope="row" class="list-group-item" >
                <span class="badge badge-primary">
                    {{row.item.id}}
                </span>
                {{row.item.name}}
                <i class="bi bi-person"></i>
            </div>
        </List>

		<!-- <TitledFrame>
			<template v-slot:title>Vue JS</template>
			<img src="../../assets/logo.png" />
		</TitledFrame> -->

		<!-- <Frame />
		<Frame> </Frame>
		<Frame> 
            <img src="../../assets/logo.png" />
        </Frame> -->

		<!-- <Button />
		<Button> Click to Change </Button>
		<Button>
			<i class="bi bi-alarm"></i>
		</Button>
		<Button>
			<i class="bi bi-person"></i>
			Profile
		</Button>
		--></div>
</template>

<script>
	// import Button from "./Button.vue";
	// import Frame from "./Frame.vue";
	// import TitledFrame from "./TitledFrame.vue";
	import List from "./List.vue";
	export default {
		components: {
			// Button,
			// Frame,
			// TitledFrame,
			List,
		},
		name: "SlotRoot",
		data() {
			return {
				listItems: [
					{ id: 1, name: "Manish" },
					{ id: 2, name: "Abhijeet" },
					{ id: 3, name: "Ramakant" },
					{ id: 4, name: "Subodh" },
				],
			};
		},
	};
</script>