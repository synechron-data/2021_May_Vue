<template>
    <div class="frame">
        <header>
            <h2>
                <slot name="title">Title</slot>
            </h2>
        </header>
        <slot>This is the default Content if nothing is sent</slot>
    </div>
</template>

<script>
    export default {
        name: "MyFrame"
    }
</script>

<style scoped>
    .frame{
        border: 2px solid blue;
    }
</style>