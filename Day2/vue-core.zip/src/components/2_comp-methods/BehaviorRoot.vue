<template>
	<div>
		<ComponentWithBehavior
			:name="'Manish'"
			:address="{ city: 'Pune', state: 'MH' }"
		/>
	</div>
</template>

<script>
	import ComponentWithBehavior from "./ComponentWithBehavior.vue";
	export default {
		name: "BehaviorRoot",
		components: { ComponentWithBehavior },
	};
</script>