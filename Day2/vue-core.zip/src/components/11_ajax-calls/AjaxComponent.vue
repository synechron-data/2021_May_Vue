<template>
	<div>
		<div class="row">
			<h2 class="text-info text-center" v-if="message">{{ message }}</h2>
		</div>
		<ul class="list-group">
			<li
				v-for="post in posts"
				v-bind:key="post.id"
				class="list-group-item"
				v-highlight
			>
				<h3>{{ post.id }}</h3>
				<h3>{{ post.title }}</h3>
				<h3>{{ post.body }}</h3>
			</li>
		</ul>
	</div>
</template>

<script>
	import postAPIService from "../../services/post-api.service";
	export default {
		name: "AjaxComponent",
		data() {
			return {
				loading: true,
				message: "Loading Data, please wait....",
				posts: [],
			};
		},
		created() {
			postAPIService
				.getAllPosts()
				.then((result) => {
					this.posts = result;
					this.message = "";
					this.loading = false;
				})
				.catch((eMsg) => {
					this.message = eMsg;
					this.loading = false;
				});
		},
	};
</script>