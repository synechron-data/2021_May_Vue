<template>
	<div>
		<h1 class="text-info">Filter Demo</h1>
		<h2 class="text-info">{{ name }}</h2>
		<h2 class="text-info">{{ name | Upper }}</h2>
		<h2 class="text-info">{{ name | Lower }}</h2>
		<hr />
		<h2>{{ user }}</h2>
		<h2>{{ user | JSON}}</h2>
	</div>
</template>

<script>
	export default {
		name: "FilterDemo",
		data() {
			return {
				user: {
					username: "msharma",
					email: "msh@gmail.com",
					countryCode: "India",
				},
				name: "Manish Sharma",
				price: 250,
				text:
					"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non ab modi repellendus labore facere, fugiat ipsam quae accusantium commodi voluptas nesciunt dolor similique ipsum accusamus earum eligendi suscipit laborum quod.",
			};
		},
		filters: {
			Upper: function (value) {
				return value.toUpperCase();
			},
			Lower: function (value) {
				return value.toLowerCase();
			},
		},
	};
</script>