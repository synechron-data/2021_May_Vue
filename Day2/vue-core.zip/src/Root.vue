<template>
	<div class="container">
		<!-- <prop-root /> -->
		<!-- <behavior-root /> -->
		<!-- <event-component /> -->
		<!-- <binding-component /> -->
		<!-- <calculator /> -->
		<!-- <counter-assignment /> -->
		<!-- <slot-root /> -->
		<!-- <dynamic-root /> -->
		<!-- <custom-directive-demo /> -->
		<!-- <filter-demo /> -->
		<ajax-component />
	</div>
</template>

<script>
	// import PropRoot from "./components/1_comp-props/PropRoot.vue";
	// import BehaviorRoot from "./components/2_comp-methods/BehaviorRoot.vue";
	// import EventComponent from "./components/3_event-handling/EventComponent.vue";
	// import BindingComponent from "./components/4_two-way-binding/BindingComponent.vue";
	// import Calculator from "./components/5_calculator-assignment/Calculator.vue";
	// import CounterAssignment from "./components/6_counter-assignment/CounterAssignment.vue";
	// import SlotRoot from "./components/7_slots/SlotRoot.vue";
	// import DynamicRoot from "./components/8_dynamic-components/DynamicRoot.vue";
	// import CustomDirectiveDemo from "./components/9_custom-directives/CustomDirectiveDemo.vue";
	// import FilterDemo from "./components/10_filters/FilterDemo.vue";
	import AjaxComponent from "./components/11_ajax-calls/AjaxComponent.vue";
	export default {
		name: "RootComponent",
		components: {
			// PropRoot,
			// BehaviorRoot,
			// EventComponent,
			// BindingComponent,
			// Calculator,
			// CounterAssignment,
			// SlotRoot,
			// DynamicRoot,
			// CustomDirectiveDemo,
			// FilterDemo,
			AjaxComponent,
		},
	};
</script>