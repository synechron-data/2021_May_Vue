const changeContent = {
    bind(el) {
        el.innerHTML = "Content Added By the Directive";
    }
}

export default changeContent;